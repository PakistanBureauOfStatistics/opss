package pk.gov.pbs.database;

public interface IDatabaseWrite {
    Long doDatabaseWriteOperation(ModelBasedDatabaseHelper db);
}
