package pk.gov.pbs.database;

import android.os.Handler;

public interface IOnSuccess {
    void onSuccess(Handler handler, Object... args);
}
