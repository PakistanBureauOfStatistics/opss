# Utility Module For Android

This repository contains utility classes for the following Operations
  - Location Service
  - File Manager
  - Compression / Decompression (ZipManager)
  - Custom Application, Activity Classes
  - UXToolkit
  - Static and System Utility
  - Other utility classes (Theme and Font Management)
