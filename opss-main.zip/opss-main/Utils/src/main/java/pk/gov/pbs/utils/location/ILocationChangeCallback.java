package pk.gov.pbs.utils.location;

import android.location.Location;

public interface ILocationChangeCallback {
    void onLocationChange(Location location);
}
