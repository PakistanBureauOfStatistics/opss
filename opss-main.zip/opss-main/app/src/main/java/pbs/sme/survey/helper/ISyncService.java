package pbs.sme.survey.helper;

public interface ISyncService {
    void syncListing(String uid);
    void syncEnumeration(String uid);
}
